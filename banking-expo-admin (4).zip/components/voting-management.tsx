"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Plus, Trophy, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Progress } from "@/components/ui/progress"

const API_BASE_URL = "https://backend.bankingexpoethiopia.com/api"

interface Nominee {
  _id: string
  name: string
  image: string
  createdAt: string
}

interface Award {
  _id: string
  title: string
  nominees: Nominee[]
  createdAt: string
}

interface VoteResult {
  nomineeId: string
  name: string
  image: string
  voteCount: number
}

interface AwardResults {
  awardTitle: string
  results: VoteResult[]
}

export default function VotingManagement() {
  const [nominees, setNominees] = useState<Nominee[]>([])
  const [awards, setAwards] = useState<Award[]>([])
  const [results, setResults] = useState<AwardResults | null>(null)
  const [loading, setLoading] = useState(true)
  const [showNomineeDialog, setShowNomineeDialog] = useState(false)
  const [showAwardDialog, setShowAwardDialog] = useState(false)
  const [selectedAwardId, setSelectedAwardId] = useState<string>("")

  const [nomineeForm, setNomineeForm] = useState({
    name: "",
    image: null as File | null,
  })

  const [awardForm, setAwardForm] = useState({
    title: "",
    nomineeIds: [] as string[],
  })

  const { toast } = useToast()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      await Promise.all([loadNominees(), loadAwards()])
    } catch (error) {
      console.error("Error loading data:", error)
    } finally {
      setLoading(false)
    }
  }

  const loadNominees = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/vote/nominees`)
      if (response.ok) {
        const data = await response.json()
        setNominees(data)
      }
    } catch (error) {
      console.error("Error loading nominees:", error)
    }
  }

  const loadAwards = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/vote/awards`)
      if (response.ok) {
        const data = await response.json()
        setAwards(data)
      }
    } catch (error) {
      console.error("Error loading awards:", error)
    }
  }

  const loadResults = async (awardId: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/vote/results/${awardId}`)
      if (response.ok) {
        const data = await response.json()
        setResults(data)
      }
    } catch (error) {
      console.error("Error loading results:", error)
      toast({ title: "Error", description: "Failed to load results", variant: "destructive" })
    }
  }

  const handleCreateNominee = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!nomineeForm.name || !nomineeForm.image) {
      toast({ title: "Error", description: "Name and image are required", variant: "destructive" })
      return
    }

    const formData = new FormData()
    formData.append("name", nomineeForm.name)
    formData.append("image", nomineeForm.image)

    try {
      const token = localStorage.getItem("adminToken")
      const response = await fetch(`${API_BASE_URL}/vote/nominees`, {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData,
      })

      if (response.ok) {
        toast({ title: "Success", description: "Nominee added successfully!" })
        setNomineeForm({ name: "", image: null })
        setShowNomineeDialog(false)
        loadNominees()
      } else {
        const error = await response.json()
        toast({ title: "Error", description: error.message || "Failed to add nominee", variant: "destructive" })
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to add nominee", variant: "destructive" })
    }
  }

  const handleCreateAward = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!awardForm.title || awardForm.nomineeIds.length === 0) {
      toast({ title: "Error", description: "Title and at least one nominee are required", variant: "destructive" })
      return
    }

    try {
      const token = localStorage.getItem("adminToken")
      const response = await fetch(`${API_BASE_URL}/vote/awards`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token && { Authorization: `Bearer ${token}` }),
        },
        body: JSON.stringify({
          title: awardForm.title,
          nomineeIds: awardForm.nomineeIds,
        }),
      })

      if (response.ok) {
        toast({ title: "Success", description: "Award created successfully!" })
        setAwardForm({ title: "", nomineeIds: [] })
        setShowAwardDialog(false)
        loadAwards()
      } else {
        const error = await response.json()
        toast({ title: "Error", description: error.message || "Failed to create award", variant: "destructive" })
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to create award", variant: "destructive" })
    }
  }

  const handleNomineeSelection = (nomineeId: string, checked: boolean) => {
    if (checked) {
      setAwardForm((prev) => ({
        ...prev,
        nomineeIds: [...prev.nomineeIds, nomineeId],
      }))
    } else {
      setAwardForm((prev) => ({
        ...prev,
        nomineeIds: prev.nomineeIds.filter((id) => id !== nomineeId),
      }))
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="loader border-4 border-gray-200 border-t-gold-500 rounded-full w-12 h-12 animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="nominees" className="w-full">
        <TabsList className="grid w-full grid-cols-3 glass-effect border-gold-600/30">
          <TabsTrigger
            value="nominees"
            className="data-[state=active]:bg-gold-600/20 data-[state=active]:text-gold-400"
          >
            Nominees
          </TabsTrigger>
          <TabsTrigger value="awards" className="data-[state=active]:bg-gold-600/20 data-[state=active]:text-gold-400">
            Awards
          </TabsTrigger>
          <TabsTrigger value="results" className="data-[state=active]:bg-gold-600/20 data-[state=active]:text-gold-400">
            Results
          </TabsTrigger>
        </TabsList>

        <TabsContent value="nominees" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-gold-400">Nominee Management</h3>
            <Dialog open={showNomineeDialog} onOpenChange={setShowNomineeDialog}>
              <DialogTrigger asChild>
                <Button className="gold-gradient text-black">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Nominee
                </Button>
              </DialogTrigger>
              <DialogContent className="glass-effect border-gold-600/30">
                <DialogHeader>
                  <DialogTitle className="text-gold-400">Add New Nominee</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateNominee} className="space-y-4">
                  <div>
                    <Label className="text-gold-300">Name</Label>
                    <Input
                      value={nomineeForm.name}
                      onChange={(e) => setNomineeForm({ ...nomineeForm, name: e.target.value })}
                      className="bg-black/50 border-gold-600/30 text-white"
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-gold-300">Image</Label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setNomineeForm({ ...nomineeForm, image: e.target.files?.[0] || null })}
                      className="bg-black/50 border-gold-600/30 text-white"
                      required
                    />
                  </div>
                  <div className="flex space-x-4">
                    <Button type="submit" className="flex-1 gold-gradient text-black">
                      Add Nominee
                    </Button>
                    <Button
                      type="button"
                      onClick={() => setShowNomineeDialog(false)}
                      className="flex-1 bg-gray-600 text-white hover:bg-gray-700"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {nominees.map((nominee) => (
              <Card key={nominee._id} className="glass-effect border-gold-600/30">
                <CardContent className="p-4">
                  <div className="text-center">
                    <img
                      src={`${API_BASE_URL.replace("/api", "")}/uploads/${nominee.image}`}
                      alt={nominee.name}
                      className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                    />
                    <h4 className="font-semibold text-white mb-2">{nominee.name}</h4>
                    <p className="text-sm text-gray-400">Added: {new Date(nominee.createdAt).toLocaleDateString()}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="awards" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-gold-400">Award Management</h3>
            <Dialog open={showAwardDialog} onOpenChange={setShowAwardDialog}>
              <DialogTrigger asChild>
                <Button className="gold-gradient text-black">
                  <Trophy className="w-4 h-4 mr-2" />
                  Create Award
                </Button>
              </DialogTrigger>
              <DialogContent className="glass-effect border-gold-600/30 max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-gold-400">Create New Award</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateAward} className="space-y-4">
                  <div>
                    <Label className="text-gold-300">Award Title</Label>
                    <Input
                      value={awardForm.title}
                      onChange={(e) => setAwardForm({ ...awardForm, title: e.target.value })}
                      className="bg-black/50 border-gold-600/30 text-white"
                      placeholder="e.g., Best Innovation Award"
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-gold-300">Select Nominees</Label>
                    <div className="grid grid-cols-2 gap-4 mt-2 max-h-60 overflow-y-auto">
                      {nominees.map((nominee) => (
                        <div key={nominee._id} className="flex items-center space-x-3 p-2 bg-black/30 rounded-lg">
                          <input
                            type="checkbox"
                            id={nominee._id}
                            checked={awardForm.nomineeIds.includes(nominee._id)}
                            onChange={(e) => handleNomineeSelection(nominee._id, e.target.checked)}
                            className="w-4 h-4 text-gold-600 bg-gray-100 border-gray-300 rounded focus:ring-gold-500"
                          />
                          <img
                            src={`${API_BASE_URL.replace("/api", "")}/uploads/${nominee.image}`}
                            alt={nominee.name}
                            className="w-8 h-8 rounded-full object-cover"
                          />
                          <label htmlFor={nominee._id} className="text-white text-sm cursor-pointer">
                            {nominee.name}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex space-x-4">
                    <Button type="submit" className="flex-1 gold-gradient text-black">
                      Create Award
                    </Button>
                    <Button
                      type="button"
                      onClick={() => setShowAwardDialog(false)}
                      className="flex-1 bg-gray-600 text-white hover:bg-gray-700"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {awards.map((award) => (
              <Card key={award._id} className="glass-effect border-gold-600/30">
                <CardHeader>
                  <CardTitle className="text-gold-400 flex items-center">
                    <Trophy className="w-5 h-5 mr-2" />
                    {award.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-gray-400 text-sm">Created: {new Date(award.createdAt).toLocaleDateString()}</p>
                    <div>
                      <p className="text-white font-medium mb-2">Nominees ({award.nominees.length}):</p>
                      <div className="flex flex-wrap gap-2">
                        {award.nominees.map((nominee) => (
                          <div
                            key={nominee._id}
                            className="flex items-center space-x-2 bg-black/30 rounded-full px-3 py-1"
                          >
                            <img
                              src={`${API_BASE_URL.replace("/api", "")}/uploads/${nominee.image}`}
                              alt={nominee.name}
                              className="w-6 h-6 rounded-full object-cover"
                            />
                            <span className="text-white text-sm">{nominee.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          <div className="flex items-center space-x-4">
            <h3 className="text-xl font-semibold text-gold-400">Voting Results</h3>
            <Select value={selectedAwardId} onValueChange={setSelectedAwardId}>
              <SelectTrigger className="w-64 bg-black/50 border-gold-600/30 text-white">
                <SelectValue placeholder="Select an award" />
              </SelectTrigger>
              <SelectContent className="bg-black border-gold-600/30">
                {awards.map((award) => (
                  <SelectItem key={award._id} value={award._id} className="text-white hover:bg-gold-600/20">
                    {award.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              onClick={() => selectedAwardId && loadResults(selectedAwardId)}
              disabled={!selectedAwardId}
              className="gold-gradient text-black"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Load Results
            </Button>
          </div>

          {results && (
            <Card className="glass-effect border-gold-600/30">
              <CardHeader>
                <CardTitle className="text-gold-400">{results.awardTitle} - Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {results.results.length > 0 ? (
                    results.results.map((result, index) => {
                      const maxVotes = Math.max(...results.results.map((r) => r.voteCount))
                      const percentage = maxVotes > 0 ? (result.voteCount / maxVotes) * 100 : 0

                      return (
                        <div key={result.nomineeId} className="flex items-center space-x-4 p-4 bg-black/30 rounded-lg">
                          <div className="flex items-center space-x-3 flex-1">
                            <div className="text-gold-400 font-bold text-lg">#{index + 1}</div>
                            <img
                              src={`${API_BASE_URL.replace("/api", "")}/uploads/${result.image}`}
                              alt={result.name}
                              className="w-12 h-12 rounded-full object-cover"
                            />
                            <div className="flex-1">
                              <p className="font-semibold text-white">{result.name}</p>
                              <p className="text-sm text-gray-400">{result.voteCount} votes</p>
                            </div>
                          </div>
                          <div className="w-32">
                            <Progress value={percentage} className="h-2" />
                          </div>
                        </div>
                      )
                    })
                  ) : (
                    <p className="text-gray-400 text-center py-8">No votes cast yet for this award.</p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
