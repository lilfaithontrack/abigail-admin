"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Plus, Edit, Trash2, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

const API_BASE_URL = "https://backend.bankingexpoethiopia.com/api"

interface Blog {
  _id: string
  title: string
  author: string
  content: string
  tags: string[]
  imageUrl: string
  createdAt: string
  updatedAt: string
}

// Quill editor component
const QuillEditor = ({ value, onChange }: { value: string; onChange: (content: string) => void }) => {
  const quillRef = useRef<any>(null)
  const editorRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (typeof window !== "undefined" && editorRef.current && !quillRef.current) {
      // Dynamically import Quill to avoid SSR issues
      import("quill").then((Quill) => {
        const QuillClass = Quill.default || Quill

        quillRef.current = new QuillClass(editorRef.current, {
          theme: "snow",
          modules: {
            toolbar: [
              [{ header: [1, 2, 3, 4, 5, 6, false] }],
              [{ font: [] }],
              [{ size: ["small", false, "large", "huge"] }],
              ["bold", "italic", "underline", "strike"],
              [{ color: [] }, { background: [] }],
              [{ script: "sub" }, { script: "super" }],
              [{ list: "ordered" }, { list: "bullet" }, { indent: "-1" }, { indent: "+1" }],
              [{ direction: "rtl" }],
              [{ align: [] }],
              ["link", "image", "video"],
              ["blockquote", "code-block"],
              ["clean"],
            ],
          },
          placeholder: "Write your blog content here...",
        })

        // Set initial content
        if (value) {
          quillRef.current.root.innerHTML = value
        }

        // Listen for text changes
        quillRef.current.on("text-change", () => {
          const content = quillRef.current.root.innerHTML
          onChange(content)
        })
      })
    }

    return () => {
      if (quillRef.current) {
        quillRef.current = null
      }
    }
  }, [])

  useEffect(() => {
    if (quillRef.current && value !== quillRef.current.root.innerHTML) {
      quillRef.current.root.innerHTML = value
    }
  }, [value])

  return (
    <>
      <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet" />
      <div ref={editorRef} className="bg-white text-black min-h-[300px] rounded-lg" style={{ minHeight: "300px" }} />
    </>
  )
}

export default function BlogManagement() {
  const [blogs, setBlogs] = useState<Blog[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [showViewDialog, setShowViewDialog] = useState(false)
  const [selectedBlog, setSelectedBlog] = useState<Blog | null>(null)
  const [blogForm, setBlogForm] = useState({
    title: "",
    author: "",
    content: "",
    tags: "",
    image: null as File | null,
  })
  const [editForm, setEditForm] = useState({
    title: "",
    author: "",
    content: "",
    tags: "",
    image: null as File | null,
  })
  const { toast } = useToast()

  useEffect(() => {
    loadBlogs()
  }, [])

  const loadBlogs = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/blogs`)
      if (response.ok) {
        const data = await response.json()
        setBlogs(data)
      } else {
        toast({ title: "Error", description: "Failed to load blogs", variant: "destructive" })
      }
    } catch (error) {
      console.error("Error loading blogs:", error)
      toast({ title: "Error", description: "Failed to load blogs", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }

  const handleCreateBlog = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!blogForm.title || !blogForm.author || !blogForm.content || !blogForm.image) {
      toast({ title: "Error", description: "All fields are required", variant: "destructive" })
      return
    }

    const formData = new FormData()
    formData.append("title", blogForm.title)
    formData.append("author", blogForm.author)
    formData.append("content", blogForm.content)
    formData.append(
      "tags",
      JSON.stringify(
        blogForm.tags
          .split(",")
          .map((tag) => tag.trim())
          .filter((tag) => tag),
      ),
    )
    formData.append("image", blogForm.image)

    try {
      const token = localStorage.getItem("adminToken")
      const response = await fetch(`${API_BASE_URL}/blogs`, {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData,
      })

      if (response.ok) {
        toast({ title: "Success", description: "Blog created successfully!" })
        setBlogForm({ title: "", author: "", content: "", tags: "", image: null })
        setShowCreateDialog(false)
        loadBlogs()
      } else {
        const error = await response.json()
        toast({ title: "Error", description: error.message || "Failed to create blog", variant: "destructive" })
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to create blog", variant: "destructive" })
    }
  }

  const handleEditBlog = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedBlog || !editForm.title || !editForm.author || !editForm.content) {
      toast({ title: "Error", description: "All fields are required", variant: "destructive" })
      return
    }

    const formData = new FormData()
    formData.append("title", editForm.title)
    formData.append("author", editForm.author)
    formData.append("content", editForm.content)
    formData.append(
      "tags",
      JSON.stringify(
        editForm.tags
          .split(",")
          .map((tag) => tag.trim())
          .filter((tag) => tag),
      ),
    )
    if (editForm.image) {
      formData.append("image", editForm.image)
    }

    try {
      const token = localStorage.getItem("adminToken")
      const response = await fetch(`${API_BASE_URL}/blogs/${selectedBlog._id}`, {
        method: "PUT",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData,
      })

      if (response.ok) {
        toast({ title: "Success", description: "Blog updated successfully!" })
        setShowEditDialog(false)
        setSelectedBlog(null)
        loadBlogs()
      } else {
        const error = await response.json()
        toast({ title: "Error", description: error.message || "Failed to update blog", variant: "destructive" })
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to update blog", variant: "destructive" })
    }
  }

  const handleDeleteBlog = async (id: string) => {
    if (!confirm("Are you sure you want to delete this blog?")) return

    try {
      const token = localStorage.getItem("adminToken")
      const response = await fetch(`${API_BASE_URL}/blogs/${id}`, {
        method: "DELETE",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })

      if (response.ok) {
        toast({ title: "Success", description: "Blog deleted successfully!" })
        loadBlogs()
      } else {
        const error = await response.json()
        toast({ title: "Error", description: error.message || "Failed to delete blog", variant: "destructive" })
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete blog", variant: "destructive" })
    }
  }

  const openEditDialog = (blog: Blog) => {
    setSelectedBlog(blog)
    setEditForm({
      title: blog.title,
      author: blog.author,
      content: blog.content,
      tags: blog.tags.join(", "),
      image: null,
    })
    setShowEditDialog(true)
  }

  const openViewDialog = (blog: Blog) => {
    setSelectedBlog(blog)
    setShowViewDialog(true)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="loader border-4 border-gray-200 border-t-gold-500 rounded-full w-12 h-12 animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gold-400">Blog Management</h2>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="gold-gradient text-black">
              <Plus className="w-4 h-4 mr-2" />
              Create Blog
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-effect border-gold-600/30 max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-gold-400">Create New Blog</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateBlog} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-gold-300">Title</Label>
                  <Input
                    value={blogForm.title}
                    onChange={(e) => setBlogForm({ ...blogForm, title: e.target.value })}
                    className="bg-black/50 border-gold-600/30 text-white"
                    required
                  />
                </div>
                <div>
                  <Label className="text-gold-300">Author</Label>
                  <Input
                    value={blogForm.author}
                    onChange={(e) => setBlogForm({ ...blogForm, author: e.target.value })}
                    className="bg-black/50 border-gold-600/30 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <Label className="text-gold-300">Content</Label>
                <QuillEditor value={blogForm.content} onChange={(content) => setBlogForm({ ...blogForm, content })} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-gold-300">Tags (comma separated)</Label>
                  <Input
                    value={blogForm.tags}
                    onChange={(e) => setBlogForm({ ...blogForm, tags: e.target.value })}
                    className="bg-black/50 border-gold-600/30 text-white"
                    placeholder="tag1, tag2, tag3"
                  />
                </div>
                <div>
                  <Label className="text-gold-300">Image</Label>
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setBlogForm({ ...blogForm, image: e.target.files?.[0] || null })}
                    className="bg-black/50 border-gold-600/30 text-white"
                    required
                  />
                </div>
              </div>

              <div className="flex space-x-4">
                <Button type="submit" className="flex-1 gold-gradient text-black">
                  Create Blog
                </Button>
                <Button
                  type="button"
                  onClick={() => setShowCreateDialog(false)}
                  className="flex-1 bg-gray-600 text-white hover:bg-gray-700"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="glass-effect border-gold-600/30 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-gold-400">Edit Blog</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditBlog} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gold-300">Title</Label>
                <Input
                  value={editForm.title}
                  onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                  className="bg-black/50 border-gold-600/30 text-white"
                  required
                />
              </div>
              <div>
                <Label className="text-gold-300">Author</Label>
                <Input
                  value={editForm.author}
                  onChange={(e) => setEditForm({ ...editForm, author: e.target.value })}
                  className="bg-black/50 border-gold-600/30 text-white"
                  required
                />
              </div>
            </div>

            <div>
              <Label className="text-gold-300">Content</Label>
              <QuillEditor value={editForm.content} onChange={(content) => setEditForm({ ...editForm, content })} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gold-300">Tags (comma separated)</Label>
                <Input
                  value={editForm.tags}
                  onChange={(e) => setEditForm({ ...editForm, tags: e.target.value })}
                  className="bg-black/50 border-gold-600/30 text-white"
                  placeholder="tag1, tag2, tag3"
                />
              </div>
              <div>
                <Label className="text-gold-300">Image (optional - leave empty to keep current)</Label>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setEditForm({ ...editForm, image: e.target.files?.[0] || null })}
                  className="bg-black/50 border-gold-600/30 text-white"
                />
              </div>
            </div>

            <div className="flex space-x-4">
              <Button type="submit" className="flex-1 gold-gradient text-black">
                Update Blog
              </Button>
              <Button
                type="button"
                onClick={() => setShowEditDialog(false)}
                className="flex-1 bg-gray-600 text-white hover:bg-gray-700"
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="glass-effect border-gold-600/30 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-gold-400">{selectedBlog?.title}</DialogTitle>
          </DialogHeader>
          {selectedBlog && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-gold-300">Author</Label>
                  <p className="text-white">{selectedBlog.author}</p>
                </div>
                <div>
                  <Label className="text-gold-300">Created</Label>
                  <p className="text-white">{new Date(selectedBlog.createdAt).toLocaleDateString()}</p>
                </div>
              </div>

              {selectedBlog.imageUrl && (
                <div>
                  <Label className="text-gold-300">Image</Label>
                  <img
                    src={`${API_BASE_URL.replace("/api", "")}/uploads/${selectedBlog.imageUrl}`}
                    alt={selectedBlog.title}
                    className="w-full max-w-md h-48 object-cover rounded-lg mt-2"
                  />
                </div>
              )}

              <div>
                <Label className="text-gold-300">Tags</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedBlog.tags.map((tag, index) => (
                    <span key={index} className="px-2 py-1 bg-gold-600/20 text-gold-300 rounded-full text-sm">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-gold-300">Content</Label>
                <div
                  className="bg-white text-black p-4 rounded-lg mt-2 prose max-w-none"
                  dangerouslySetInnerHTML={{ __html: selectedBlog.content }}
                />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Card className="glass-effect border-gold-600/30">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-black/30">
                <tr>
                  <th className="text-left p-4 text-gold-400">Title</th>
                  <th className="text-left p-4 text-gold-400 hidden md:table-cell">Author</th>
                  <th className="text-left p-4 text-gold-400 hidden lg:table-cell">Created</th>
                  <th className="text-left p-4 text-gold-400 hidden lg:table-cell">Updated</th>
                  <th className="text-left p-4 text-gold-400">Actions</th>
                </tr>
              </thead>
              <tbody>
                {blogs.length > 0 ? (
                  blogs.map((blog) => (
                    <tr key={blog._id} className="border-b border-gray-700/50">
                      <td className="p-4">
                        <div>
                          <p className="font-medium text-white">{blog.title}</p>
                          <p className="text-sm text-gray-400 md:hidden">{blog.author}</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {blog.tags.slice(0, 2).map((tag, index) => (
                              <span key={index} className="px-1 py-0.5 bg-gold-600/20 text-gold-300 rounded text-xs">
                                {tag}
                              </span>
                            ))}
                            {blog.tags.length > 2 && (
                              <span className="text-xs text-gray-400">+{blog.tags.length - 2} more</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-gray-300 hidden md:table-cell">{blog.author}</td>
                      <td className="p-4 text-gray-300 hidden lg:table-cell">
                        {new Date(blog.createdAt).toLocaleDateString()}
                      </td>
                      <td className="p-4 text-gray-300 hidden lg:table-cell">
                        {new Date(blog.updatedAt).toLocaleDateString()}
                      </td>
                      <td className="p-4">
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            onClick={() => openViewDialog(blog)}
                            className="p-2 bg-green-600/20 text-green-400 hover:bg-green-600/30"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => openEditDialog(blog)}
                            className="p-2 bg-blue-600/20 text-blue-400 hover:bg-blue-600/30"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => handleDeleteBlog(blog._id)}
                            className="p-2 bg-red-600/20 text-red-400 hover:bg-red-600/30"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="text-center p-8 text-gray-400">
                      No blogs created yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
