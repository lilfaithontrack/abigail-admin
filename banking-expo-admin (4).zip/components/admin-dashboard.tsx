"use client"

import { useState } from "react"
import { Crown, LayoutDashboard, FileText, Users, Mail, Vote, Menu, LogOut, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import Dashboard from "./dashboard"
import BlogManagement from "./blog-management"
import VotingManagement from "./voting-management"
import UserManagement from "./user-management"
import ContactManagement from "./contact-management"

interface AdminDashboardProps {
  onLogout: () => void
}

type Section = "dashboard" | "blogs" | "voting" | "users" | "contacts"

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [activeSection, setActiveSection] = useState<Section>("dashboard")
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleLogout = () => {
    localStorage.removeItem("adminToken")
    onLogout()
  }

  const navigation = [
    { id: "dashboard", name: "Dashboard", icon: LayoutDashboard },
    { id: "blogs", name: "Blog Management", icon: FileText },
    { id: "voting", name: "Voting System", icon: Vote },
    { id: "users", name: "User Management", icon: Users },
    { id: "contacts", name: "Contact Messages", icon: Mail },
  ]

  const sectionTitles = {
    dashboard: "Dashboard",
    blogs: "Blog Management",
    voting: "Voting System",
    users: "User Management",
    contacts: "Contact Messages",
  }

  const renderSection = () => {
    switch (activeSection) {
      case "dashboard":
        return <Dashboard />
      case "blogs":
        return <BlogManagement />
      case "voting":
        return <VotingManagement />
      case "users":
        return <UserManagement />
      case "contacts":
        return <ContactManagement />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="min-h-screen">
      {/* Sidebar */}
      <div
        className={`sidebar fixed inset-y-0 left-0 w-64 glass-effect border-r border-gold-600/30 z-50 transform transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} md:translate-x-0`}
      >
        <div className="p-6">
          <div className="flex items-center space-x-3 mb-8">
            <div className="w-10 h-10 gold-gradient rounded-lg flex items-center justify-center">
              <Crown className="w-6 h-6 text-black" />
            </div>
            <div>
              <h2 className="font-bold text-gold-400">Admin Panel</h2>
              <p className="text-xs text-gray-400">Banking Expo Ethiopia</p>
            </div>
          </div>

          <nav className="space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(item.id as Section)
                    setSidebarOpen(false)
                  }}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                    activeSection === item.id ? "bg-gold-600/20 text-gold-400" : "hover:bg-gold-600/20 text-gray-300"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.name}</span>
                </button>
              )
            })}
          </nav>
        </div>

        <div className="absolute bottom-6 left-6 right-6">
          <Button
            onClick={handleLogout}
            className="w-full flex items-center space-x-3 p-3 rounded-lg bg-red-600/20 hover:bg-red-600/30 transition-colors text-red-300"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </Button>
        </div>
      </div>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main Content */}
      <div className="md:ml-64 min-h-screen transition-all duration-300">
        {/* Header */}
        <header className="glass-effect border-b border-gold-600/30 p-4 md:p-6 sticky top-0 z-40">
          <div className="flex items-center justify-between">
            <Button onClick={() => setSidebarOpen(true)} className="md:hidden text-gold-400 p-2" variant="ghost">
              <Menu className="w-6 h-6" />
            </Button>
            <h1 className="text-2xl font-bold text-gold-400">{sectionTitles[activeSection]}</h1>
            <div className="flex items-center space-x-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm text-gray-300">Welcome back,</p>
                <p className="font-semibold text-gold-400">Administrator</p>
              </div>
              <div className="w-10 h-10 gold-gradient rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-black" />
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="p-4 md:p-6">{renderSection()}</div>
      </div>
    </div>
  )
}
